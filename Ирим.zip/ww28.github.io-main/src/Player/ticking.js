function insta() {
	window.mehitting = true
	setTimeout(()=>{
		window.dmg = "40";
		window.skinUrl = "https://raw.githubusercontent.com/ww28/ww28.github.io/main/img/Katana_1_E.webp"
		setTimeout(()=>{
					window.dmg = "25";
		window.skinUrl = "https://raw.githubusercontent.com/ww28/ww28.github.io/main/img/Bow_1_E.webp"
			setTimeout(()=>{
		window.mehitting = false
	}, 100)
	}, 120)
	}, 120)
}
function click() {
	document.querySelector("canvas").dispatchEvent(click)
}
window.ticking = false;
setInterval(()=>{
	if (ticking) {
		let dist = Math.hypot(window.playerPos.x - window.nearest.x, window.playerPos.y - window.nearest.y)
			window.playerPos.x += window.playerPos.x / 8 + Math.cos(Math.atan2(window.playerPos.x - window.nearest.x, window.playerPos.y - window.nearest.y))
			if (Math.hypot(window.playerPos.x - window.nearest.x, window.playerPos.y - window.nearest.y) > 600) {
				window.playerPos.x -= window.playerPos.x / 7 + Math.cos(Math.atan2(window.playerPos.x - window.nearest.x, window.playerPos.y - window.nearest.y))
			}
			if (Math.hypot(window.playerPos.x - window.nearest.x, window.playerPos.y - window.nearest.y) < 800 && Math.hypot(window.playerPos.x - window.nearest.x, window.playerPos.y - window.nearest.y) > 600) {
			    ticking = false;
			    insta()
			    console.log("stopped")
			}
}
	
}, 11)
window.addEventListener("keydown", function(e) {
	if (e.keyCode == 82) {
			ticking = 1;
	}
})