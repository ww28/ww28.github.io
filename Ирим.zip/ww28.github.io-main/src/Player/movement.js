let playerSpeed = 0;
function lerp(oldpos, pos) {
    return oldpos * (1-0.1) + pos * 0.1;
}
window.playerPos={};
window.playerPos.y = 0;
window.playerPos.x = 0;
let newPositions = {
	x:0,
	y:0
}

setInterval(()=>{
	window.playerPos = {
		x: lerp(playerPos.x, newPositions.x),
		y: lerp(playerPos.y, newPositions.y)
	};
	if (keyW || eo("w")) {
		newPositions.y = window.playerPos.y - (playerSpeed /* - window.resources.blood*/);
		moveMap(0, -20)
	} else if (keyA || eo("a")) {
		newPositions.y = window.playerPos.y + (playerSpeed /* - window.resources.blood */);	
		moveMap(0, 20);
	} else if (keyS || eo("s")) {
		newPositions.x = window.playerPos.x - (playerSpeed /* - window.resources.blood */);
		moveMap(20, 0)
	} else if (keyD || eo("d")) {
		newPositions.x = window.playerPos.x + (playerSpeed /* - window.resources.blood */);
		moveMap(-20, 0)
	}
},4);
window.clicked = ""
function eo(key) {
  if (clicked == key) {setTimeout(()=>{clicked=0}, 240); return 1};
}
const ep = document.createElement('div');
ep.style = `
width: 30%;
height: 30%;
background: rgba(0, 0, 0, 0.5);
z-index: 9;
position: absolute;
bottom: 0;
left: 60%;
font-size: 8px !important;
`;
ep.innerHTML = `
<button id = "w" onclick = "window.clicked = 'w'" style = "left: 25%; top: 0; position: absolute; width: 50%; height: 25%;">W</button>
<button id = "a" onclick = "window.clicked = 'a'" style = "left: 0%; top: 25%; position: absolute; width: 50%; height: 25%;">A</button>
<button id = "s" onclick = "window.clicked = 's'" style = "right: 0%; top: 25%; position: absolute; width: 50%; height: 25%;">S</button>
<button id = "d" onclick = "window.clicked = 'd'" style = "right: 25%; top: 50%; position: absolute; width: 50%; height: 25%;">D</button><hr>
`
document.body.append(ep)
window.addEventListener("keydown", e => {
    switch(e.keyCode) {
        case 87:
             keyW = true;
        break;
        case 83:
             keyA = true;
        break;
        case 68:
             keyS = true;
             break;
        case 65:
             keyD = true;
        break;
    }
});
let keyW, keyA, keyS, keyD = 0;
window.addEventListener("keyup", e=> {
    switch(e.keyCode) {
        case 87:
             keyW = 0;
        break;
        case 83:
             keyA = 0;
        break;
        case 68:
             keyS = 0;
             break;
        case 65:
             keyD = 0;
        break;
    }
});
